package Prision;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class Agregar {
    public static void main(String[] args) {
        ConecxionDB CDB = new ConecxionDB();
        Connection connection = CDB.getConnection();

        AgregarPreso(connection);
        AgregarGuardia(connection);
    }

    public static void AgregarPreso(Connection connection) {
        if (connection == null) {
            System.out.println("No hay conexión con la base de datos.");
            return;
        }

        Scanner sc = new Scanner(System.in);
        String nombre = " ", alias = " ", tiempoCondena = " ", fechaIngresoPrision=" ",nacionalidad =" ",detallesFisicoPreso=" ",detalleCondena=" ";

        System.out.println("DATOS DEL PRISIONERO");
        System.out.println("nombre:");
        nombre = sc.nextLine();
        System.out.println("alias:");
        alias = sc.nextLine();
        System.out.println("fecha Ingreso Prision:");
        fechaIngresoPrision = sc.nextLine();
        System.out.println("tiempo de condena en años:");
        tiempoCondena = sc.nextLine();
        System.out.println("nacionalidad:");
        nacionalidad = sc.nextLine();
        System.out.println("detalles fisicos del preso:");
        detallesFisicoPreso = sc.nextLine();
        System.out.println("detalle de la(s) condenas:");
        detalleCondena = sc.nextLine();

        String sql = "INSERT INTO prisionero(nombre, alias,fechaIngresoPrision, tiempoCondena, nacionalidad,detallesFisicoPreso,detalleCondena) VALUES(?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, nombre);
            stmt.setString(2, alias);
            stmt.setString(3, fechaIngresoPrision);
            stmt.setString(4, tiempoCondena);
            stmt.setString(5, nacionalidad);
            stmt.setString(6, detallesFisicoPreso);
            stmt.setString(7, detalleCondena);

            stmt.executeUpdate();

            System.out.println("Se agregó correctamente el prisionero.");

        } catch (SQLException e) {
            System.out.println(e);
        }
    }

    public static void AgregarGuardia(Connection connection) {
        if (connection == null) {
            System.out.println("No hay conexión con la base de datos.");
            return;
        }

        Scanner sc = new Scanner(System.in);
        String nombre = " ", puesto = " ",rango = " ";
        int  edad = 0;

        System.out.println("DATOS DEL GUARDIA");
        System.out.println("nombre:");
        nombre = sc.nextLine();
        System.out.println("edad:");
        edad = sc.nextInt();
        System.out.println("puesto:");
        sc.nextLine();
        puesto = sc.nextLine();
        System.out.println("rango:");
        rango = sc.nextLine();

        String sql = "INSERT INTO guardias(nombre, edad, puesto, rango) VALUES(?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, nombre);
            stmt.setInt(2, edad);
            stmt.setString(3, puesto);
            stmt.setString(4, rango);

            stmt.executeUpdate();

            System.out.println("Se agregó correctamente el guardia.");

        } catch (SQLException e) {
            System.out.println(e);
        }
    }

    public static void AgregarPersonalTrabajo(Connection connection) {
        if (connection == null) {
            System.out.println("No hay conexión con la base de datos.");
            return;
        }

        Scanner sc = new Scanner(System.in);
        String nombre = " ", puesto = " ",fechaIngreso = " ";
        int  edad = 0;

        System.out.println("DATOS DEL TRABAJADOR");
        System.out.println("nombre:");
        nombre = sc.nextLine();
        System.out.println("edad:");
        edad = sc.nextInt();
        System.out.println("puesto:");
        sc.nextLine();
        puesto = sc.nextLine();
        System.out.println("fecha de ingreso:");
        fechaIngreso = sc.nextLine();

        String sql = "INSERT INTO personaltrabajadores (nombre, edad, puesto,fechaIngreso) VALUES(?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, nombre);
            stmt.setInt(2, edad);
            stmt.setString(3, puesto);
            stmt.setString(4, fechaIngreso);

            stmt.executeUpdate();

            System.out.println("Se agregó correctamente el guardia.");

        } catch (SQLException e) {
            System.out.println(e);
        }
    }

}
