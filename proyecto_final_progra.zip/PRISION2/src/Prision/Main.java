package Prision;

import Prision.VerListas.*;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);


        ConecxionDB CDB = new ConecxionDB();
        Connection connection = CDB.getConnection();


        if (connection == null) {
            System.out.println("Error: No se pudo establecer la conexión a la base de datos.");
            return;
        } else {
            System.out.println("Conexión a la base de datos establecida.");
        }

        int opcionMenu, opcionAgregar, opcionBuscar,opcionEliminar;
        List<ListaPresos> ListadePresos = null;
        Verlistas verlistas = new Verlistas();
        List<ListaGuardias> listaGuardias = null;
        Verlistas verlistasG = new Verlistas();
        List<ListaPersonalTrabajo> listaPersonalTrabajo = null;
        Verlistas verlistasT = new Verlistas();

        do {
            System.out.println("ELIJA UNA OPCIÓN:");
            System.out.println("------------MENÚ-----------");
            System.out.println("1.- agregar");
            System.out.println("2.- listar (ver datos)");
            System.out.println("3.- modificar");
            System.out.println("4.- eliminar");
            System.out.println("0.- salir");

            opcionMenu = sc.nextInt();

            switch (opcionMenu) {

                case 1:
                    do {
                        System.out.println("ELIJA UNA OPCIÓN PARA AGREGAR:");
                        System.out.println("------------MENÚ-----------");
                        System.out.println("1.- agregar preso");
                        System.out.println("2.- agregar guardia");
                        System.out.println("3.- agregar personal de trabajo");
                        System.out.println("0.- atras");

                        opcionAgregar = sc.nextInt();
                        switch (opcionAgregar) {
                            case 1:
                                Agregar.AgregarPreso(connection);
                                break;
                            case 2:
                                Agregar.AgregarGuardia(connection);
                                break;
                            case 3:
                                Agregar.AgregarPersonalTrabajo(connection);
                                break;
                        }
                    } while (opcionAgregar != 0);
                    break;

                case 2:
                    do {
                        System.out.println("ELIJA UNA OPCIÓN PARA BUSCAR:");
                        System.out.println("------------MENÚ-----------");
                        System.out.println("1.- buscar un preso especifico");
                        System.out.println("2.- buscar un guardia especifico");
                        System.out.println("3.- buscar personal de trabajo");
                        System.out.println("0.- atras");

                        opcionBuscar = sc.nextInt();
                        switch (opcionBuscar) {
                            case 1:
                                System.out.println("Buscar un preso específico");
                                System.out.println("ingrese el identificador del preso");
                                int idp = sc.nextInt();
                                Ver V2 = new Ver(connection, idp, TipoEntidad.PRESO);
                                ListadePresos = V2.VerPreso();
                                verlistas.MostrarListaPresos(ListadePresos);
                                break;
                            case 2:
                                System.out.println("Buscar un guardia específico");
                                System.out.println("ingrese el identificador del guardia");
                                int idg = sc.nextInt();
                                Ver V3 = new Ver(connection, idg, TipoEntidad.GUARDIA);
                                listaGuardias = V3.VerGuardia();
                                verlistasG.MostrarListaGuardias(listaGuardias);
                                break;
                            case 3:
                                System.out.println("Buscar personal de trabajo");
                                System.out.println("ingrese el identificador del trabajador");
                                int idt = sc.nextInt();
                                Ver V4 = new Ver(connection, idt, TipoEntidad.PERSONAL_TRABAJO);
                                listaPersonalTrabajo = V4.VerPersonalTrabajo();
                                verlistasT.MostrarListaPersonalTrabajo(listaPersonalTrabajo);
                                break;
                        }
                    } while (opcionBuscar != 0);
                    break;

                case 3:

                    Modificar.modificarPreso(connection,sc);
                    break;

                case 4:

                    do{
                        System.out.println("ELIJA UNA OPCIÓN PARA ELIMINAR:");
                        System.out.println("------------MENÚ-----------");
                        System.out.println("1.- eliminar un preso especifico");
                        System.out.println("2.- eliminar un guardia especifico");
                        System.out.println("3.- eliminar un trabajador específico ");
                        System.out.println("0.- atras");

                        opcionEliminar= sc.nextInt();

                        switch (opcionEliminar){
                            case 1:
                                System.out.println("eliminar preso");
                                System.out.println("ingrese el identificador del preso");
                                Eliminar.eliminarPreso(connection,sc);
                                break;

                            case 2:
                                System.out.println("eliminar guardia");
                                System.out.println("ingrese el identificador del guardia");
                                Eliminar.eliminarGuardia(connection,sc);
                                break;
                            case 3:
                                System.out.println("eliminar personal de trabajo");
                                System.out.println("ingrese el identificador del trabajador");
                                Eliminar.eliminarPersonalTrabajo(connection,sc);
                                break;
                        }

                    }while(opcionEliminar!=0);

            }
        } while (opcionMenu != 0);
    }
}


