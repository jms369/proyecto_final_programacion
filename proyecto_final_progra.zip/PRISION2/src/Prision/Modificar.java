package Prision;

import Prision.VerListas.ListaPresos;
import Prision.VerListas.Ver;
import Prision.VerListas.TipoEntidad;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

public class Modificar {


    public static void modificarPreso(Connection connection, Scanner sc) {

        System.out.println("Ingrese el identificador del preso que desea modificar:");
        int idPreso = sc.nextInt();


        if (idPreso <= 0) {
            System.out.println("El identificador debe ser un número positivo.");
            return;
        }


        Ver V2 = new Ver(connection, idPreso, TipoEntidad.PRESO);
        List<ListaPresos> ListadePresos = V2.VerPreso();

        if (ListadePresos.isEmpty()) {
            System.out.println("No se encontró ningún preso con ese identificador.");
            return;
        }


        ListaPresos preso = ListadePresos.get(0);
        System.out.println("Datos actuales del preso:");
        System.out.println("Nombre: " + preso.getNombre());
        System.out.println("Alias: " + preso.getAlias());
        System.out.println("Tiempo de condena: " + preso.getTiempoCondena() + " años");


        System.out.println("Ingrese el nuevo nombre (deje en blanco para no modificar):");
        sc.nextLine();
        String nuevoNombre = sc.nextLine();

        System.out.println("Ingrese el nuevo alias (deje en blanco para no modificar):");
        String nuevoAlias = sc.nextLine();

        System.out.println("Ingrese el nuevo tiempo de condena (en años, 0 para no modificar):");
        int nuevoTiempoCondena = sc.nextInt();


        String sqlUpdate = "UPDATE prisionero SET nombre = ?, alias = ?, tiempoCondena = ? WHERE id = ?";

        try (PreparedStatement statement = connection.prepareStatement(sqlUpdate)) {
            if (!nuevoNombre.isEmpty()) {
                statement.setString(1, nuevoNombre);
            } else {
                statement.setString(1, preso.getNombre());
            }

            if (!nuevoAlias.isEmpty()) {
                statement.setString(2, nuevoAlias);
            } else {
                statement.setString(2, preso.getAlias());
            }

            if (nuevoTiempoCondena != 0) {
                statement.setInt(3, nuevoTiempoCondena);
            } else {
                statement.setInt(3, preso.getTiempoCondena());
            }

            statement.setInt(4, idPreso);


            int filasAfectadas = statement.executeUpdate();
            if (filasAfectadas > 0) {
                System.out.println("Datos del preso modificados correctamente.");
            } else {
                System.out.println("No se pudo modificar los datos.");
            }
        } catch (SQLException e) {
            System.out.println("Error al modificar los datos: " + e.getMessage());
        }
    }
}


