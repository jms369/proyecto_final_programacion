package Prision;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class Eliminar {


    public static void eliminarPreso(Connection connection, Scanner sc) {

        System.out.println("Ingrese el identificador del preso que desea eliminar:");
        int idPreso = sc.nextInt();


        if (idPreso <= 0) {
            System.out.println("El identificador debe ser un número positivo.");
            return;
        }


        String sqlDelete = "DELETE FROM prisionero WHERE id = ?";

        try (PreparedStatement statement = connection.prepareStatement(sqlDelete)) {
            statement.setInt(1, idPreso);


            int filasAfectadas = statement.executeUpdate();
            if (filasAfectadas > 0) {
                System.out.println("Preso eliminado correctamente.");
            } else {
                System.out.println("No se encontró ningún preso con ese identificador.");
            }
        } catch (SQLException e) {
            System.out.println("Error al eliminar los datos: " + e.getMessage());
        }
    }

    public static void eliminarGuardia(Connection connection, Scanner sc) {

        System.out.println("Ingrese el identificador del preso que desea eliminar:");
        int idGuardia = sc.nextInt();


        if (idGuardia <= 0) {
            System.out.println("El identificador debe ser un número positivo.");
            return;
        }


        String sqlDelete = "DELETE FROM guardias WHERE id = ?";

        try (PreparedStatement statement = connection.prepareStatement(sqlDelete)) {
            statement.setInt(1, idGuardia);


            int filasAfectadas = statement.executeUpdate();
            if (filasAfectadas > 0) {
                System.out.println("guardia eliminado correctamente.");
            } else {
                System.out.println("No se encontró ningún guardia con ese identificador.");
            }
        } catch (SQLException e) {
            System.out.println("Error al eliminar los datos: " + e.getMessage());
        }
    }

    public static void eliminarPersonalTrabajo(Connection connection, Scanner sc) {

        System.out.println("Ingrese el identificador del trabajador que desea eliminar:");
        int idPersonalTrabajo = sc.nextInt();


        if (idPersonalTrabajo <= 0) {
            System.out.println("El identificador debe ser un número positivo.");
            return;
        }


        String sqlDelete = "DELETE FROM personaltrabajadores WHERE id = ?";

        try (PreparedStatement statement = connection.prepareStatement(sqlDelete)) {
            statement.setInt(1, idPersonalTrabajo);


            int filasAfectadas = statement.executeUpdate();
            if (filasAfectadas > 0) {
                System.out.println("trabajador eliminado correctamente.");
            } else {
                System.out.println("No se encontró ningún preso con ese identificador.");
            }
        } catch (SQLException e) {
            System.out.println("Error al eliminar los datos: " + e.getMessage());
        }
    }
}

