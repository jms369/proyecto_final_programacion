package Prision.VerListas;

public enum TipoEntidad {
    PRESO, GUARDIA, PERSONAL_TRABAJO;
}
