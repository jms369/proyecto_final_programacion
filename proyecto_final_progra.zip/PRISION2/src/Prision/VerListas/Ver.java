package Prision.VerListas;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Ver {
    private Connection connection;
    private int identificador;
    private TipoEntidad tipoEntidad;
    public Ver(Connection connection, int identificador, TipoEntidad tipoEntidad) {
        if (connection == null) {
            throw new IllegalArgumentException("La conexión no puede ser nula.");
        }
        if (identificador <= 0) {
            throw new IllegalArgumentException("El identificador debe ser un número positivo.");
        }
        this.connection = connection;
        this.identificador = identificador;
        this.tipoEntidad = tipoEntidad;
    }


    public List<ListaPresos> VerPreso() {
        if (tipoEntidad != TipoEntidad.PRESO) {
            throw new IllegalArgumentException("Este método es solo para presos.");
        }
        List<ListaPresos> ListadePresos = new ArrayList<>();

        String sql = "SELECT nombre, alias,fechaIngresoPrision, tiempoCondena, nacionalidad,detallesFisicoPreso, detalleCondena FROM prisionero WHERE id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, identificador);

            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    String nombre = resultSet.getString("nombre");
                    String alias = resultSet.getString("alias");
                    String fechaIngresoPrision = resultSet.getString("fechaIngresoPrision");
                    int tiempoCondena = resultSet.getInt("tiempoCondena");
                    String nacionalidad = resultSet.getString("nacionalidad");
                    String detallesFisicoPreso = resultSet.getString("detallesFisicoPreso");
                    String detalleCondena = resultSet.getString("detalleCondena");

                    ListaPresos lp = new ListaPresos(nombre, alias,fechaIngresoPrision, tiempoCondena,nacionalidad,detallesFisicoPreso,detalleCondena);
                    ListadePresos.add(lp);
                }
            } catch (SQLException e) {
                throw new RuntimeException("Error al obtener los datos del preso: " + e.getMessage(), e);
            }

        } catch (SQLException e) {
            throw new RuntimeException("Error al preparar la consulta: " + e.getMessage(), e);
        }

        return ListadePresos;
    }

    public List<ListaGuardias> VerGuardia() {
        if (tipoEntidad != TipoEntidad.GUARDIA) {
            throw new IllegalArgumentException("Este método es solo para guardias.");
        }
        List<ListaGuardias> listaGuardias = new ArrayList<>();
        String sql = "SELECT nombre,edad,puesto, rango FROM guardias WHERE id = ?";

        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, identificador);

            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    String nombre = resultSet.getString("nombre");
                    int edad = resultSet.getInt("edad");
                    String puesto = resultSet.getString("puesto");
                    String rango = resultSet.getString("rango");

                    ListaGuardias lg = new ListaGuardias(nombre, edad, puesto, rango);
                    listaGuardias.add(lg);
                }
            } catch (SQLException e) {
                throw new RuntimeException("Error al obtener los datos del guardia: " + e.getMessage(), e);
            }

        } catch (SQLException e) {
            throw new RuntimeException("Error al preparar la consulta del guardia: " + e.getMessage(), e);
        }

        return listaGuardias;
    }

    public List<ListaPersonalTrabajo> VerPersonalTrabajo() {
        if (tipoEntidad != TipoEntidad.PERSONAL_TRABAJO) {
            throw new IllegalArgumentException("Este método es solo para personal de trabajo.");
        }
        List<ListaPersonalTrabajo> listaPersonal = new ArrayList<>();
        String sql = "SELECT nombre,edad, puesto, fechaIngreso FROM personaltrabajadores WHERE id = ?";

        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, identificador);

            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    String nombre = resultSet.getString("nombre");
                    int edad = resultSet.getInt("edad");
                    String puesto = resultSet.getString("puesto");
                    String fechaIngreso = resultSet.getString("fechaIngreso");

                    ListaPersonalTrabajo lp = new ListaPersonalTrabajo(nombre,edad, puesto, fechaIngreso);
                    listaPersonal.add(lp);
                }
            } catch (SQLException e) {
                throw new RuntimeException("Error al obtener los datos del personal de trabajo: " + e.getMessage(), e);
            }

        } catch (SQLException e) {
            throw new RuntimeException("Error al preparar la consulta del personal de trabajo: " + e.getMessage(), e);
        }

        return listaPersonal;
    }
}








