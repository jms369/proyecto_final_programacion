package Prision.VerListas;

public class ListaPresos {
    private String nombre;
    private String alias;
    private int tiempoCondena;
    private String fechaIngresoPrision;
    private String nacionalidad;
    private String detallesFisicoPreso;
    private String detalleCondena;

    public ListaPresos(String nombre, String alias,String fechaIngresoPrision, int tiempoCondena,String nacionalidad,String detallesFisicoPreso,String detalleCondena) {
        this.nombre = nombre;
        this.alias = alias;
        this.fechaIngresoPrision = fechaIngresoPrision;
        this.tiempoCondena = tiempoCondena;
        this.nacionalidad = nacionalidad;
        this.detallesFisicoPreso = detallesFisicoPreso;
        this.detalleCondena = detalleCondena;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getAlias() {
        return alias;
    }

    public void setAlias(String alias) {
        this.alias = alias;
    }

    public String getFechaIngresoPrision() {
        return fechaIngresoPrision;
    }

    public void setFechaIngresoPrision(String fechaIngresoPrision) {
        this.fechaIngresoPrision = fechaIngresoPrision;
    }

    public int getTiempoCondena() {
        return tiempoCondena;
    }

    public void setTiempoCondena(int tiempoCondena) {
        this.tiempoCondena = tiempoCondena;
    }

    public String getNacionalidad() {
        return nacionalidad;
    }

    public void setNacionalidad(String nacionalidad) {
        this.nacionalidad = nacionalidad;
    }

    public String getDetallesFisicoPreso() {
        return detallesFisicoPreso;
    }

    public void setDetallesFisicoPreso(String detallesFisicoPreso) {
        this.detallesFisicoPreso = detallesFisicoPreso;
    }

    public String getDetalleCondena() {
        return detalleCondena;
    }

    public void setDetalleCondena(String detalleCondena) {
        this.detalleCondena = detalleCondena;
    }
}


