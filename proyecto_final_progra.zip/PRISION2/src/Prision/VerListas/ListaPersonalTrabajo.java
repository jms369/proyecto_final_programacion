package Prision.VerListas;

public class ListaPersonalTrabajo {
    private String nombre;
    private int edad;
    private String puesto;
    private String fechaIngreso;

    public ListaPersonalTrabajo(String nombre,int edad, String puesto, String fechaIngreso) {
        this.nombre = nombre;
        this.puesto = puesto;
        this.edad= edad;
        this.fechaIngreso = fechaIngreso;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getPuesto() {
        return puesto;
    }

    public void setPuesto(String puesto) {
        this.puesto = puesto;
    }
    public String getFechaIngreso() {
        return fechaIngreso;
    }

    public void setFechaIngreso(String fechaIngreso) {
        this.fechaIngreso = fechaIngreso;
    }
}

