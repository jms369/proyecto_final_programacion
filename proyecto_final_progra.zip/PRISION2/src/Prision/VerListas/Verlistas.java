package Prision.VerListas;

import java.util.List;

public class Verlistas {


    public void MostrarListaPresos(List<ListaPresos> ListadePresos) {
        System.out.println("*** Lista de Prisioneros ***");
        if (ListadePresos.isEmpty()) {
            System.out.println("No hay presos registrados.");
        } else {
            for (ListaPresos listaPresos : ListadePresos) {
                System.out.println("----------------------------------");
                System.out.println(" ");
                System.out.println("Nombre: " + listaPresos.getNombre());
                System.out.println("Alias: " + listaPresos.getAlias());
                System.out.println("fechaIngresoPrision: " + listaPresos.getFechaIngresoPrision());
                System.out.println("Tiempo de condena: " + listaPresos.getTiempoCondena()+" años");
                System.out.println("nacionalidad: " + listaPresos.getNacionalidad());
                System.out.println("detalles Fisicos del Preso: " + listaPresos.getDetallesFisicoPreso());
                System.out.println("Detalles de la(s) Condena(s): " + listaPresos.getDetalleCondena());
                System.out.println(" ");
                System.out.println("----------------------------------");

            }
        }
    }


    public void MostrarListaGuardias(List<ListaGuardias> listaGuardias) {
        System.out.println("*** Lista de Guardias ***");
        if (listaGuardias.isEmpty()) {
            System.out.println("No hay guardias registrados.");
        } else {
            for (ListaGuardias listaGuardia : listaGuardias) {
                System.out.println("----------------------------------");
                System.out.println(" ");
                System.out.println("Nombre: " + listaGuardia.getNombre());
                System.out.println("Edad: " + listaGuardia.getEdad());
                System.out.println("Puesto: " + listaGuardia.getPuesto());
                System.out.println("Rango: " + listaGuardia.getRango());
                System.out.println(" ");
                System.out.println("----------------------------------");
            }
        }
    }


    public void MostrarListaPersonalTrabajo(List<ListaPersonalTrabajo> listaPersonal) {
        System.out.println("*** Lista de Personal de Trabajo ***");
        if (listaPersonal.isEmpty()) {
            System.out.println("No hay personal de trabajo registrado.");
        } else {
            for (ListaPersonalTrabajo personal : listaPersonal) {
                System.out.println("----------------------------------");
                System.out.println(" ");
                System.out.println("Nombre: " + personal.getNombre());
                System.out.println("Edad: " + personal.getEdad());
                System.out.println("Puesto: " + personal.getPuesto());
                System.out.println("Fecha de ingreso: " + personal.getFechaIngreso());
                System.out.println(" ");
                System.out.println("----------------------------------");

            }
        }
    }
}



