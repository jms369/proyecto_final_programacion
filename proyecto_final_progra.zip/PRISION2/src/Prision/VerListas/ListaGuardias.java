package Prision.VerListas;

public class ListaGuardias {
    private String nombre;
    private int edad;
    private String puesto;
    private String rango;

    public ListaGuardias(String nombre, int edad, String puesto, String rango) {
        this.nombre = nombre;
        this.edad = edad;
        this.puesto = puesto;
        this.rango = rango;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getPuesto() {
        return puesto;
    }

    public void setPuesto(String puesto) {
        this.puesto = puesto;
    }

    public String getRango() {
        return rango;
    }

    public void setRango(String rango) {
        this.rango = rango;
    }
}
